import 'package:flutter/material.dart';
import '../pages/profile_page.dart';

class ProfileIconButton extends StatelessWidget {
  final double iconSize;

  const ProfileIconButton({super.key, this.iconSize = 40.0});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(
        right: 16.0,
        top: 10.0,
      ),
      child: IconButton(
        iconSize: iconSize,
        splashRadius: iconSize + 8,
        icon: Icon(
          Icons.person,
          size: iconSize,
          color: Colors.white,
        ),
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const ProfilePage()),
          );
        },
      ),
    );
  }
}
