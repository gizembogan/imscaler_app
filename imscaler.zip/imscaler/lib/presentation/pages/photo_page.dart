import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:image/image.dart' as img;

import '../widgets/background_container.dart';
import '../widgets/profile_icon.dart';
import 'upload_page.dart';

class PhotoPage extends StatefulWidget {
  final Uint8List imageData;
  const PhotoPage({super.key, required this.imageData});

  @override
  State<PhotoPage> createState() => _PhotoPageState();
}

class _PhotoPageState extends State<PhotoPage> {
  bool _isSaved = false;

  Future<void> _saveImageWithRedSquare(Uint8List imageData) async {
    // Android 11+ tüm dosyalara erişim izni
    if (Platform.isAndroid &&
        !(await Permission.manageExternalStorage
            .request()
            .isGranted)) return;
    // iOS için Fotoğraflara yazma izni (gerekiyorsa)
    if (!Platform.isAndroid &&
        !(await Permission.photos
            .request()
            .isGranted)) return;

    final original = img.decodeImage(imageData);
    if (original == null) return;

    // Kırmızı çerçeve çizimi
    const int squareSize = 80;
    final cx = original.width ~/ 2,
        cy = original.height ~/ 2;
    final l = cx - squareSize ~/ 2,
        t = cy - squareSize ~/ 2;
    final r = cx + squareSize ~/ 2,
        b = cy + squareSize ~/ 2;
    final red = img.ColorRgb8(255, 0, 0);

    for (var x = l; x <= r; x++) {
      if (t >= 0 && t < original.height) original.setPixel(x, t, red);
      if (b >= 0 && b < original.height) original.setPixel(x, b, red);
    }
    for (var y = t; y <= b; y++) {
      if (l >= 0 && l < original.width) original.setPixel(l, y, red);
      if (r >= 0 && r < original.width) original.setPixel(r, y, red);
    }

    final out = Uint8List.fromList(img.encodeJpg(original));
    final dir = Directory('/storage/emulated/0/DCIM/Camera');
    if (!dir.existsSync()) dir.createSync(recursive: true);

    final file = File(
        '${dir.path}/imscaler_${DateTime
            .now()
            .millisecondsSinceEpoch}.jpg'
    );
    await file.writeAsBytes(out);

    setState(() => _isSaved = true);
    await Future.delayed(const Duration(seconds: 3));
    if (!mounted) return;
    setState(() => _isSaved = false);
  }

  void _openFullScreenImage() {
    showDialog(
      context: context,
      builder: (_) =>
          Scaffold(
            backgroundColor: Colors.black,
            body: GestureDetector(
              onTap: () => Navigator.pop(context), // Ekrana dokununca kapanır
              child: Center(
                child: InteractiveViewer(
                  minScale: 1.0,
                  maxScale: 4.0,
                  child: LayoutBuilder(
                    builder: (context, constraints) {
                      final width = constraints.maxWidth;
                      return Stack(
                        alignment: Alignment.center,
                        children: [
                          // Cihaz genişliğine tam oturan fotoğraf
                          Image.memory(
                            widget.imageData,
                            width: width,
                            fit: BoxFit.fitWidth,
                          ),
                          // Ortadaki kırmızı kare (ekranın yarısı genişlikte)
                          Container(
                            width: width * 0.5,
                            height: width * 0.5,
                            decoration: BoxDecoration(
                              border: Border.all(color: Colors.red, width: 3),
                              borderRadius: BorderRadius.circular(4),
                            ),
                          ),
                        ],
                      );
                    },
                  ),
                ),
              ),
            ),
          ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        title: const Text(
          "ImScaler",
          style: TextStyle(
            fontSize: 28,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        actions: const [ProfileIconButton()],
      ),
      body: BackgroundContainer(
        child: Center( // ← Burada ekledik
          child: Column(
            mainAxisSize: MainAxisSize.min, // ← İçerik kadar yükseklik
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              GestureDetector(
                onTap: _openFullScreenImage,
                child: Container(
                  width: 250,
                  height: 250,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      ClipRRect(
                        borderRadius: BorderRadius.circular(20),
                        child: Image.memory(
                          widget.imageData,
                          fit: BoxFit.cover,
                          width: 250,
                          height: 250,
                        ),
                      ),
                      Container(
                        width: 80,
                        height: 80,
                        decoration: BoxDecoration(
                          border: Border.all(color: Colors.red, width: 3),
                          borderRadius: BorderRadius.circular(4),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    icon: const Icon(
                        Icons.arrow_back, color: Colors.white, size: 30),
                    onPressed: () =>
                        Navigator.pushAndRemoveUntil(
                          context,
                          MaterialPageRoute(builder: (_) => const UploadPage()),
                              (route) => false,
                        ),
                  ),
                  const SizedBox(width: 40),
                  IconButton(
                    icon: const Icon(
                        Icons.bookmark_border, color: Colors.white, size: 30),
                    onPressed: () => _saveImageWithRedSquare(widget.imageData),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              if (_isSaved)
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 16, vertical: 8),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.7),
                    borderRadius: BorderRadius.circular(25),
                  ),
                  child: const Text(
                    "SAVED TO GALLERY!",
                    style: TextStyle(
                      color: Colors.deepPurple,
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
