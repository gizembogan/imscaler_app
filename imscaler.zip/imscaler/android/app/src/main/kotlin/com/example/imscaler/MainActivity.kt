package com.example.imscaler

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
